function manage(pos,price){
  const tp=pos.entry*1.003;
  const sl=pos.entry*0.997;
  if(price>=tp) return 'TP';
  if(price<=sl) return 'SL';
  return null;
}
module.exports={manage};
