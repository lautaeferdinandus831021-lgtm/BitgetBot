const {generateSMCSignal} = require('../strategy/smc');
const {validateM1} = require('../strategy/m1Validator');
const {getOrderFlow} = require('../strategy/orderFlow');
const {sendOrder} = require('../ws/execution');

function run(state){
  const {b5,b1,bids,asks,trades} = state;

  if(b5.length<10 || b1.length<5) return;

  const trend = generateSMCSignal(b5);
  if(!trend) return;

  if(!validateM1(b1, trend.type)) return;

  const flow = getOrderFlow(bids,asks,trades,b1[b1.length-1]);
  if(!flow || flow.type!==trend.type) return;

  sendOrder(trend);
}

module.exports={run};
