async function retry(fn){
  try{return await fn();}
  catch(e){return fn();}
}
module.exports={retry};
