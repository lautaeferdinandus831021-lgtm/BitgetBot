function validateM1(c,d){
  const l=c.slice(-5);
  let b=0,s=0;
  l.forEach(x=>x.close>x.open?b++:s++);
  if(d==='BUY' && b>=3) return true;
  if(d==='SELL' && s>=3) return true;
  return false;
}
module.exports={validateM1};
