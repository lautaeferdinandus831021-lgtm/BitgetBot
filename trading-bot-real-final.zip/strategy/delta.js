let pb=0,pa=0;
function getDelta(b,a){
  const bv=b.slice(0,10).reduce((s,x)=>s+parseFloat(x[1]),0);
  const av=a.slice(0,10).reduce((s,x)=>s+parseFloat(x[1]),0);
  const db=bv-pb, da=av-pa;
  pb=bv; pa=av;
  if(db>50) return 'BUY';
  if(da>50) return 'SELL';
  return null;
}
module.exports={getDelta};
