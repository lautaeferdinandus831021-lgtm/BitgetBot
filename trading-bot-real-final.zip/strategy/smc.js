function generateSMCSignal(c){
  const last=c.slice(-10);
  const high=Math.max(...last.map(x=>x.high));
  const low=Math.min(...last.map(x=>x.low));
  const close=last[last.length-1].close;

  if(close>high*0.995) return {type:'BUY'};
  if(close<low*1.005) return {type:'SELL'};
  return null;
}
module.exports={generateSMCSignal};
