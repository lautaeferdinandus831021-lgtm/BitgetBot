function tapeSignal(t){
  let b=0,s=0;
  t.forEach(x=>x.side==='buy'?b+=x.size:s+=x.size);
  if(b>s*1.5) return 'BUY';
  if(s>b*1.5) return 'SELL';
  return null;
}
module.exports={tapeSignal};
