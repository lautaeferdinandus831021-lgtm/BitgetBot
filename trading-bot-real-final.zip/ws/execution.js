const WebSocket=require('ws');
let ws;

function connect(){
  ws=new WebSocket('wss://ws.bitget.com/mix/v1/stream');
}

function sendOrder(signal){
  if(!ws || ws.readyState!==1) return;
  ws.send(JSON.stringify({
    op:'trade',
    args:[{
      symbol:'BTCUSDT',
      marginCoin:'USDT',
      size:'0.001',
      side:signal.type==='BUY'?'open_long':'open_short',
      orderType:'market',
      clientOid:'BOT-'+Date.now()
    }]
  }));
}
module.exports={connect,sendOrder};
