const {run} = require('./core/engine');

let state={
  b5:[], b1:[],
  bids:[], asks:[],
  trades:[]
};

setInterval(()=>{
  run(state);
},50);
